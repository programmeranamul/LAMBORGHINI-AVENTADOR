import React from 'react';
import Canvas from './Canvas';

const Visualizer = () => {
    
    return (
        <div>
            <Canvas />
        </div>
    );
};

export default Visualizer;