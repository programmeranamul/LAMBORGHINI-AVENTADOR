export const singleProductDetailsData = [
  {
    title: "Born to be worn.",
    text: "Clip on the worlds most wearable music player and take up to 240 songs with you anywhere. Choose from five colors including four new hues to make your musical fashion statement.",
  },
  {
    title: "Random meets rhythm.",
    text: "With iTunes autofill, iPod shuffle can deliver a new musical experience every time you sync. For more randomness, you can shuffle songs during playback with the slide of a switch.",
  },
  {
    title: "Everything is easy.",
    text: "Charge and sync with the included USB dock. Operate the iPod shuffle controls with one hand. Enjoy up to 12 hours straight of skip-free music playback.",
  },
  {
    title: "Intel Core 2 Duo processor",
    text: "Powered by an Intel Core 2 Duo processor at speeds up to 2.16GHz, the new MacBook is the fastest ever.",
  },
  {
    title: "1GB memory, larger hard drives",
    text: "The new MacBook now comes with 1GB of memory standard and larger hard drives for the entire line perfect for running more of your favorite applications and storing growing media collections.",
  },
  {
    title: "Sleek, 1.08-inch-thin design",
    text: "MacBook makes it easy to hit the road thanks to its tough polycarbonate case, built-in wireless technologies, and innovative MagSafe Power Adapter that releases automatically if someone accidentally trips on the cord.",
  },
  {
    title: "Built-in iSight camera",
    text: "Right out of the box, you can have a video chat with friends or family,2 record a video at your desk, or take fun pictures with Photo Booth",
  },
];
