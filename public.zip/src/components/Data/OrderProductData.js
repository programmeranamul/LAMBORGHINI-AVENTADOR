import image from "./../../images/3.jpg"

export const orderProductList = [
    {
        image: image, quantity : 6, title:"Sushila Autotechnik- SATuned", price:"19800"
    },
    {
        image: image, quantity : 7, title:"Sushila Autotechnik- SATuned", price:"67000"
    },
    {
        image: image, quantity : 3, title:"Sushila Autotechnik- SATuned", price:"12000"
    },
]
