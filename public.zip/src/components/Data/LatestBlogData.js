import image from "./../../images/car.jpg";

export const BlogData = [
  {
    img: image,
    date: "25",
    month: "feb",
    author: "programmer anamul",
    title: "Ladipiscing erat llentesque pellentesque eton",
    description:
      "Lorem ipsum dolor sit amet. Integer adipiscing erat llentesque sollicitudin pellentesque et non erat....",
  },
  {
    img: image,
    date: "25",
    month: "feb",
    author: "programmer anamul",
    title: "Ladipiscing erat llentesque pellentesque eton",
    description:
      "Lorem ipsum dolor sit amet. Integer adipiscing erat llentesque sollicitudin pellentesque et non erat....",
  },
  {
    img: image,
    date: "25",
    month: "feb",
    author: "programmer anamul",
    title: "Ladipiscing erat llentesque pellentesque eton",
    description:
      "Lorem ipsum dolor sit amet. Integer adipiscing erat llentesque sollicitudin pellentesque et non erat....",
  },
];
