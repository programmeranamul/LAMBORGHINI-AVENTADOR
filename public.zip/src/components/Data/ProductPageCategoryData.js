export const listCategoryData = [
  {
    title: "categories",
    cat: [
      " Clothing (9 items)",
      " Fashion (9 items)",
      "Featured (9 items)",
      "Sounds (9 items)",
    ],
  },
];
export const checkboxCategoryData = [
  {
    title: "color",
    cat: ["Black", "Blue", "Brown", "Green", "grey", "red", "white"],
  },
  {
    title: "price",
    cat: ["0-100", "0-99", "100-150"],
  },
  {
    title: "size",
    cat: ["l", "large", "m", "medium", "s", "small", "xl"],
  },
  {
    title: "type",
    cat: ["chinese", "original", "used"],
  },
];
