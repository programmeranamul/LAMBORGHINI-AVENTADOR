import user1 from "./../../images/user1.jpg";

export const testimonialData = [
  {
    name: "Anamul",
    image: user1,
    text: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim laborum  repellen voluptate deleniti consectetur necessitatibus",
  },
  {
    name: "Programmer",
    image: user1,
    text: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim laborum  repellen voluptate deleniti consectetur necessitatibus",
  },
  {
    name: "Haque",
    image: user1,
    text: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim laborum  repellen voluptate deleniti consectetur necessitatibus",
  },
];
