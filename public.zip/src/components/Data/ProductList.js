import car from "./../../images/car.jpg";

export const productData = [
  {
    category: "NEW COLLECTION",
    title: "NEW COLLECTION 2020-2021",
    offer: "Sell up to 20% off",
    image: car,
  },
  {
    category: "NEW COLLECTION",
    title: "high performance",
    offer: "Sell up to 20% off",
    image: car,
  },
  {
    category: "NEW COLLECTION",
    title: "red sale ends april 30",
    offer: "Sell up to 20% off",
    image: car,
  },
];
