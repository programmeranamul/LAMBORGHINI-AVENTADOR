import React from 'react';
import ProductSection from '../../components/ProductDetailsComponent/ProductSection';
import RelatedProducts from '../../components/ProductDetailsComponent/RelatedProducts';
import PageBanner from '../../components/commonComponent/PageBanner/PageBanner';
import ProductDetails from '../../components/ProductDetailsComponent/ProductDetails';
import TecnicalData from '../../components/ProductDetailsComponent/TecnicalData';
import AudioSection from '../../components/ProductDetailsComponent/AudioSection';
import Audio1 from '../../components/ProductDetailsComponent/Audio1';
import Audio2 from '../../components/ProductDetailsComponent/Audio2';


const ProductDetailsPage = () => {
    return (
        <div >
           <PageBanner title="Sushila Autotechnik- SATuned" dontShowTitle={true}  menu={true}/>
           <ProductSection />
           <RelatedProducts />
           <ProductDetails />
           <Audio1 />
           {/* <Audio2 /> */}
           {/* <AudioSection /> */}
           <TecnicalData />
        </div>
    );
};

export default ProductDetailsPage;